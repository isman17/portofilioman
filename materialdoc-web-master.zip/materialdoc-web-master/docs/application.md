# Android Application

I am happy to announce that we just released open source [Android application](https://github.com/materialdoc/materialdoc) which includes all source code (layouts, styles, colors) of [materialdoc.com](http://www.materialdoc.com) tutorials.

You can [download apk](https://play.google.com/store/apps/details?id=com.materialdoc) and check how material components will look on different Android versions.

<div>
    <table>
        <tr>
            <td>
                <img width="350" src="/images/screenshot-1-1.png">
             </td>
            <td>
                <img width="350" src="/images/screenshot-2-1.png">
             </td>
        </tr>
    </table>
</div>
